-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1:3306
-- 產生時間： 2024-06-27 03:58:57
-- 伺服器版本： 8.0.31
-- PHP 版本： 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `cloude03`
--
CREATE DATABASE IF NOT EXISTS `cloude03` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `cloude03`;

-- --------------------------------------------------------

--
-- 資料表結構 `about`
--

DROP TABLE IF EXISTS `about`;
CREATE TABLE IF NOT EXISTS `about` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lan` int DEFAULT NULL,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `about`
--

INSERT INTO `about` (`id`, `lan`, `title`, `content`, `photo`) VALUES
(2, 1, '2023', '65464532', '2024_03_07_14_35_01_681.png');

-- --------------------------------------------------------

--
-- 資料表結構 `about_advance`
--

DROP TABLE IF EXISTS `about_advance`;
CREATE TABLE IF NOT EXISTS `about_advance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lan` int DEFAULT NULL,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `about_advance`
--

INSERT INTO `about_advance` (`id`, `lan`, `title`, `content`, `photo`) VALUES
(1, 1, '2022', '1234', '2024_03_07_10_53_07_959.png');

-- --------------------------------------------------------

--
-- 資料表結構 `about_content`
--

DROP TABLE IF EXISTS `about_content`;
CREATE TABLE IF NOT EXISTS `about_content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lan` int DEFAULT NULL,
  `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `about_note`
--

DROP TABLE IF EXISTS `about_note`;
CREATE TABLE IF NOT EXISTS `about_note` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lan` int DEFAULT NULL,
  `years` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `about_note`
--

INSERT INTO `about_note` (`id`, `lan`, `years`, `content`) VALUES
(1, 1, '2021', 'html'),
(2, 1, '2022', 'php'),
(3, 1, '2023', 'api'),
(4, 1, '2024', '專案'),
(5, 1, '2024', 'vue');

-- --------------------------------------------------------

--
-- 資料表結構 `banner`
--

DROP TABLE IF EXISTS `banner`;
CREATE TABLE IF NOT EXISTS `banner` (
  `id` int NOT NULL AUTO_INCREMENT,
  `apId` int DEFAULT NULL,
  `photo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `banner`
--

INSERT INTO `banner` (`id`, `apId`, `photo`) VALUES
(5, 0, '2024_03_06_14_02_49_034.mp4'),
(2, 3, '2024_03_08_10_12_42_627.png'),
(6, 1, '2024_03_07_13_43_28_491.png');

-- --------------------------------------------------------

--
-- 資料表結構 `counter`
--

DROP TABLE IF EXISTS `counter`;
CREATE TABLE IF NOT EXISTS `counter` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dates` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lan` int DEFAULT NULL,
  `cnt` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dates` (`dates`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `counter`
--

INSERT INTO `counter` (`id`, `dates`, `lan`, `cnt`) VALUES
(1, '2024/3/13', 1, 3),
(2, '2024/3/13', 2, 2),
(3, '2024/3/12', 1, 3),
(4, '2024/3/15', 1, 2),
(5, '2024/3/19', 1, 1),
(6, '2024/3/21', 1, 1),
(7, '2024/3/26', 1, 1),
(8, '2024/4/1', 1, 1),
(9, '2024/4/2', 1, 1);

-- --------------------------------------------------------

--
-- 資料表結構 `labels`
--

DROP TABLE IF EXISTS `labels`;
CREATE TABLE IF NOT EXISTS `labels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `labels` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lan` int DEFAULT NULL,
  `title` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `labels` (`labels`,`lan`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `labels`
--

INSERT INTO `labels` (`id`, `labels`, `lan`, `title`, `content`) VALUES
(2, '關於', 1, '關於我們', '關於我們'),
(3, '優勢', 1, '優勢', '優勢'),
(4, '記事', 1, '記事', '記事1'),
(6, '首頁', 1, '首頁', NULL),
(7, '首頁', 2, 'Home', NULL),
(8, '關於', 2, 'About Us', NULL),
(9, '優勢', 2, 'Advance', NULL),
(10, '記事', 2, 'TimeLine', NULL);

-- --------------------------------------------------------

--
-- 資料表結構 `lan`
--

DROP TABLE IF EXISTS `lan`;
CREATE TABLE IF NOT EXISTS `lan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` char(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `lan`
--

INSERT INTO `lan` (`id`, `title`, `active`) VALUES
(1, '中文', 'Y'),
(2, '英文', 'N');

-- --------------------------------------------------------

--
-- 資料表結構 `layer1`
--

DROP TABLE IF EXISTS `layer1`;
CREATE TABLE IF NOT EXISTS `layer1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lan` int DEFAULT NULL,
  `layer1_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分類:名稱',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `layer1`
--

INSERT INTO `layer1` (`id`, `lan`, `layer1_name`) VALUES
(1, 1, '121213'),
(9, 2, 'BBBBB');

-- --------------------------------------------------------

--
-- 資料表結構 `manager`
--

DROP TABLE IF EXISTS `manager`;
CREATE TABLE IF NOT EXISTS `manager` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '帳號',
  `pwd` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密碼',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='後台管理者';

--
-- 傾印資料表的資料 `manager`
--

INSERT INTO `manager` (`id`, `userId`, `pwd`) VALUES
(1, '111', '111');

-- --------------------------------------------------------

--
-- 資料表結構 `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lan` int DEFAULT NULL COMMENT '語系',
  `app` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `menu`
--

INSERT INTO `menu` (`id`, `lan`, `app`, `url`) VALUES
(1, 1, '關於我們', 'about'),
(2, 1, '最新消息', 'news'),
(3, 1, '產品介紹', 'product'),
(4, 2, 'About', 'about'),
(5, 2, 'News', 'news'),
(6, 2, 'Product', 'product');

-- --------------------------------------------------------

--
-- 資料表結構 `menus`
--

DROP TABLE IF EXISTS `menus`;
CREATE TABLE IF NOT EXISTS `menus` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2024_02_19_084348_create_menus_table', 1);

-- --------------------------------------------------------

--
-- 資料表結構 `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int NOT NULL AUTO_INCREMENT,
  `typeId` int DEFAULT NULL,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subTitle` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `dates` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `news`
--

INSERT INTO `news` (`id`, `typeId`, `title`, `subTitle`, `photo`, `content`, `dates`, `createDate`) VALUES
(1, 1, '546', '6464', '2024_03_21_16_16_01_816.jpg', '<p>545474</p>', '2024-03-14', '2024-03-21 08:16:01');

-- --------------------------------------------------------

--
-- 資料表結構 `news_type`
--

DROP TABLE IF EXISTS `news_type`;
CREATE TABLE IF NOT EXISTS `news_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lan` int DEFAULT NULL,
  `title` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `news_type`
--

INSERT INTO `news_type` (`id`, `lan`, `title`) VALUES
(1, 1, '1234');

-- --------------------------------------------------------

--
-- 資料表結構 `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lan` int DEFAULT NULL,
  `layer1` int DEFAULT NULL COMMENT '分類id',
  `itemNo` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '產品編號',
  `itemName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '品名',
  `subName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '小標',
  `active` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Y:使用中 N:不使用',
  `home` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Y:首頁',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `product`
--

INSERT INTO `product` (`id`, `lan`, `layer1`, `itemNo`, `itemName`, `subName`, `active`, `home`) VALUES
(4, 1, 1, '1', '1', '2', 'Y', 'Y'),
(5, 1, 1, '2', '2', '2', 'Y', 'Y'),
(19, 2, 9, '542', '45245', '45245', 'Y', 'Y');

-- --------------------------------------------------------

--
-- 資料表結構 `product_content`
--

DROP TABLE IF EXISTS `product_content`;
CREATE TABLE IF NOT EXISTS `product_content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `itemId` int DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `product_content`
--

INSERT INTO `product_content` (`id`, `itemId`, `content`) VALUES
(1, 19, '<p>你好</p>'),
(2, 21, '<p>你好</p>'),
(3, 22, '<p>786</p>'),
(4, 23, '<p>456465456</p>'),
(5, 24, '<p>453</p>'),
(6, 4, NULL);

-- --------------------------------------------------------

--
-- 資料表結構 `product_photo`
--

DROP TABLE IF EXISTS `product_photo`;
CREATE TABLE IF NOT EXISTS `product_photo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `itemId` int DEFAULT NULL COMMENT '產品編號',
  `photo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '產品圖',
  PRIMARY KEY (`id`),
  KEY `itemId` (`itemId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `product_photo`
--

INSERT INTO `product_photo` (`id`, `itemId`, `photo`) VALUES
(4, 5, '2024_01_24_08_20_37_803.png'),
(8, 19, '2024_03_05_10_24_37_968.png'),
(11, 4, '2024_03_07_12_57_00_224.png');

-- --------------------------------------------------------

--
-- 資料表結構 `product_shop`
--

DROP TABLE IF EXISTS `product_shop`;
CREATE TABLE IF NOT EXISTS `product_shop` (
  `id` int NOT NULL AUTO_INCREMENT,
  `itemId` int DEFAULT NULL COMMENT '產品編號',
  `shopId` int DEFAULT NULL COMMENT '商品編號',
  `url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '網址',
  PRIMARY KEY (`id`),
  KEY `itemId` (`itemId`,`shopId`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `product_shop`
--

INSERT INTO `product_shop` (`id`, `itemId`, `shopId`, `url`) VALUES
(1, 4, 1, NULL),
(2, 5, 1, '21'),
(18, 19, 1, '2452');

-- --------------------------------------------------------

--
-- 資料表結構 `shop`
--

DROP TABLE IF EXISTS `shop`;
CREATE TABLE IF NOT EXISTS `shop` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商店名稱',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `shop`
--

INSERT INTO `shop` (`id`, `title`) VALUES
(1, '586'),
(2, '生活用品');

-- --------------------------------------------------------

--
-- 資料表結構 `spec`
--

DROP TABLE IF EXISTS `spec`;
CREATE TABLE IF NOT EXISTS `spec` (
  `id` int NOT NULL AUTO_INCREMENT,
  `itemId` int DEFAULT NULL COMMENT '產品編號',
  `title` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '規格',
  `content` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '內容',
  PRIMARY KEY (`id`),
  KEY `itemId` (`itemId`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `spec`
--

INSERT INTO `spec` (`id`, `itemId`, `title`, `content`) VALUES
(4, 4, '1', '1'),
(5, 5, '2', '2'),
(27, 23, '456', '456456'),
(28, 24, 'abc', 'abc');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
