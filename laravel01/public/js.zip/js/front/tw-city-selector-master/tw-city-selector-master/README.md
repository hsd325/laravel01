## 說明

### 文件：[https://dennykuo.github.io/tw-city-selector](https://dennykuo.github.io/tw-city-selector)

如果資料有誤或未及更新，發個 [issue](https://github.com/dennykuo/tw-city-selector/issues ':target=_blank') 給我吧

## 開發

安裝依賴

```
npm install
或
yarn install
```

編譯

```
npm run build
或
npm run watch
```

Local server

```
npm run start
```
