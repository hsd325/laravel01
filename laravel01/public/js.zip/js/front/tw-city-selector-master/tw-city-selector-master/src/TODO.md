### 近期 todo

- 自訂屬性
- React
- Vue
- 指定 element 時，tag 錯誤的提示
- 指定 el 設定時，bootstrap 樣式需要忽略


### 遠期 todo

- 3 + 2 碼解決方式
- 依據目前所在位置選擇
