import Vue from '../../node_modules/vue/dist/vue.min.js';
import docsify from '../../node_modules/docsify/lib/docsify.min.js';

window.Vue = Vue;
window.$docsify = docsify;
